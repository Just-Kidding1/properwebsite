function Button(){
    let button = document.getElementById("button0")

    num1 = 4;
    num2 = .5;
    alert(num1 + num2);
}